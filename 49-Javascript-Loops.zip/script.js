var total = 10;
for (var x = 0; x < total; x++) {
  console.log(x);
}


var students = ["joao", "jacob", "jingle", "aloha"];

console.log(students.length);
for (x=0; x < students.length; x++) {
  
  console.log(students[x]);
}