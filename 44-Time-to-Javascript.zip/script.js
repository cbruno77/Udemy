var name = "Carlos";
var age = 42;

var message = "Olá, o meu nome é " + name + " e tenho " + age  + " anos de idade.";

// alert(message);

console.log(message);

// prompt(message);